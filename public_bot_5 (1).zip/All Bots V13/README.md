# v14'e Geçmeden Önce Kullandığm Tüm Botlar
Merhabalar bu botlar paylaştığım Monarch v13 ün aynı yapısındadır. Komut taslakları ve daha fazlası burdardır bu bot mot işleri baya baydı neyse baya işinize yarıcak eminim bundan muhtemelen şuan çoğu tanınan botcular alıp içinden kod çekip veya aynısını kurup dicek ki ramal mı ha çöp şase yapmayın sizin gibi lamerlarla işim olmaz hemde bu kadar çok bekleyip sniper gibi profilimi avlıyorlar çerezlerinde de ramalfxden başka bişi çıkmıyo neysem gelelim konumuza site api ile kurulum işlemi yaptırtabilirsiniz.
Paylaşcam sözü vardı dcyide artık umursamadığıma göre gönül rahatlıyla kullanabilirsiniz. Botları test etmek istiyorsanız discord.gg/percius sunucusuna girerek botlara bakabilirsiniz. Welcome olarakta son paylaştığımı kullanabilirsiniz. Ha rat mevzuzuna gelicem Astech denen bi sunucu vardı onun için zamanında microsofta çalışan botcuları varmıştı benim botu kullananda onlar için yapılan bir şeydi bu dosyaları ayıklayarak kontrol edebilirsiniz iyi günler emojiler içinde sunucu atıcam stat yapısı çok garip haberiniz olsun baştan söyleyim çok fazla ram yer o yüzden dolayıda paylaşmak istedim. https://discord.gg/PAeAQWV3 bu sunucudan da emojileri çekebilirsiniz.
İçinden sms, whatsapp ve telegram sistemi kaldırılmıştır bunuda baştan söyleyim.

Bide yardım için yazmayın beceremiyosan da kurmayı bırak açık ve net!
Video çekip atıcam işime gelirse

Şimdiden iyi kullanımlar iyi çalmalar hakkım helal olsun inşallah güzel yerlere gelirsiniz daha da sözüm yok. Hayırlı günler.
